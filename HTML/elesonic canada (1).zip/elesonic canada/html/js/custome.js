



// banner-slider
jQuery("#banner-slider").owlCarousel({

  autoplay:true,
  margin:2,
  responsiveClass: true,
  autoplayTimeout:8000,
  smartSpeed:2000,
  items:1,
  loop:true,
  nav:false,
  dots: false,
  
});

// banner-slider

// seller-slider

jQuery("#products-slider").owlCarousel( {

    margin:12,
    autoplay: true,
    responsiveClass: true,
    autoplayTimeout: 5000,
    smartSpeed: 800,
    loop:false,
    nav:true,
    dots:false,
     responsive: {
      0: {
        items: 1
      },
      600: {
        items:2
      },
      1200: {
        items:4
      }
    }
});

// seller-slider


// seller-slider

jQuery("#elesonic-slider").owlCarousel( {

    margin:12,
    autoplay: true,
    responsiveClass: true,
    autoplayTimeout: 5000,
    smartSpeed: 800,
    loop:false,
    nav:true,
    dots:false,
     responsive: {
      0: {
        items: 1
      },
      600: {
        items:2
      },
      1200: {
        items:6
      }
    }
});

// seller-slider


// seller-slider

jQuery("#logo-slider").owlCarousel( {

    margin:10,
    autoplay: true,
    responsiveClass: true,
    autoplayTimeout: 4000,
    smartSpeed: 600,
    loop:true,
    nav:false,
    dots:false,
     responsive: {
      0: {
        items: 1
      },
      600: {
        items:2
      },

      992: {
        items:4
      },

      1200: {
        items:7
      }
    }
});

// seller-slider









