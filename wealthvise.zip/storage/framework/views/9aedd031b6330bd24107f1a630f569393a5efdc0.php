<?php $__env->startSection('pageheader', 'Reset Password'); ?>



<?php $__env->startSection('content'); ?>
    <div class="login-box">
        <div class="login-logo">
            <a href="<?php echo e(route('index')); ?>"><b>Larav</b>IRST</a>
        </div>

        <div class="login-box-body">
            <p class="login-box-msg">Reset Password</p>

            <form action="<?php echo e(route('password.update')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="token" value="<?php echo e($token); ?>">

                <div class="form-group has-feedback">
                    <input type="email" class="form-control" value="<?php echo e($email ?? old('email')); ?>" name="email" placeholder="Email" required readonly>
                    <span class="fa fa-envelope form-control-feedback"></span>
                </div>

                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="password" placeholder="Password">
                    <span class="fa fa-lock form-control-feedback"></span>
                </div>

                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password">
                    <span class="fa fa-lock form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Reset Password</button>
                    </div>
                </div>

                <br>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>