<aside class="main-sidebar">
    <section class="sidebar">
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(Auth::user()->avatar); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::user()->name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        

        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>

            <li class="<?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <?php if(Myhelper::hasrole(['superadmin','admin'])): ?>
                <?php if(Myhelper::can(['view_admins', 'view_banks', 'view_customers'])): ?>
                    <li class="treeview <?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'members') ? 'active menu-open' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="fa fa-user-circle"></i> <span>Members</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Myhelper::can('view_customers')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'customer') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.members.index', ['type' => 'customer'])); ?>"><i class="fa fa-circle-o"></i> Customers</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('view_banks')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'bank') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.members.index', ['type' => 'bank'])); ?>"><i class="fa fa-circle-o"></i> Banks</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('view_admins')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'admin') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.members.index', ['type' => 'admin'])); ?>"><i class="fa fa-circle-o"></i> Admins</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Myhelper::can(['view_membership_packages'])): ?>
                    <li class="treeview <?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'resources') ? 'active menu-open' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="fa fa-globe"></i> <span>Resources</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Myhelper::can('view_membership_packages')): ?>
                                <li class="treeview <?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'packages') ? 'active' : ''); ?>">
                                    <a href="#"><i class="fa fa-circle-o"></i> Membership Packages
                                        <span class="pull-right-container">
                                            <i class="fa fa-angle-left pull-right"></i>
                                        </span>
                                    </a>
                                    <ul class="treeview-menu">
                                        <li class="<?php echo e((isset($activemenu['child']) && $activemenu['child'] == 'agent') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.resources.packages', ['type' => 'agent'])); ?>"><i class="fa fa-circle-o"></i> Agents</a></li>
                                        <li class="<?php echo e((isset($activemenu['child']) && $activemenu['child'] == 'bank') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.resources.packages', ['type' => 'bank'])); ?>"><i class="fa fa-circle-o"></i> Banks</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Myhelper::can(['view_faqs', 'view_contents', 'view_testimonials'])): ?>
                    <li class="treeview <?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'cms') ? 'active menu-open' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="fa fa-gears"></i> <span>Content Management</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Myhelper::can('view_faqs')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'faqs') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.cms.index', ['type' => 'faqs'])); ?>"><i class="fa fa-circle-o"></i> FAQs</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('view_contents')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'contents') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.cms.index', ['type' => 'contents'])); ?>"><i class="fa fa-circle-o"></i> CMS</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('view_testimonials')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'testimonials') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.cms.index', ['type' => 'testimonials'])); ?>"><i class="fa fa-circle-o"></i> Testimonials</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Myhelper::can(['view_blogs', 'add_blog'])): ?>
                    <li class="treeview <?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'blogs') ? 'active menu-open' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="fa fa-newspaper-o"></i> <span>Blogs Management</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Myhelper::can('add_blog')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'add') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.blogs.add')); ?>"><i class="fa fa-circle-o"></i> Create New</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('view_blogs')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'index') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.blogs.index')); ?>"><i class="fa fa-circle-o"></i> View All</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Myhelper::can(['account_notification', 'sms_notification', 'push_notification', 'email_notification'])): ?>
                    <li class="treeview <?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'notifications') ? 'active menu-open' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="fa fa-bell"></i> <span>Notifications</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <?php if(Myhelper::can('account_notification')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'account') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.notifications.index', ['type' => 'account'])); ?>"><i class="fa fa-circle-o"></i> Account Notification</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('sms_notification')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'sms') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.notifications.index', ['type' => 'sms'])); ?>"><i class="fa fa-circle-o"></i> SMS Notification</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('push_notification')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'push') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.notifications.index', ['type' => 'push'])); ?>"><i class="fa fa-circle-o"></i> Push Notification</a></li>
                            <?php endif; ?>

                            <?php if(Myhelper::can('email_notification')): ?>
                                <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'email') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.notifications.index', ['type' => 'email'])); ?>"><i class="fa fa-circle-o"></i> Email Notification</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Myhelper::hasrole('superadmin')): ?>
                    <li class="treeview <?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'tools') ? 'active menu-open' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="fa fa-gear"></i> <span>Roles & Permission</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'roles') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.tools.roles')); ?>"><i class="fa fa-circle-o"></i> Roles</a></li>
                            <li class="<?php echo e((isset($activemenu['sub']) && $activemenu['sub'] == 'permissions') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.tools.permissions')); ?>"><i class="fa fa-circle-o"></i> Permissions</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(Myhelper::hasrole('superadmin')): ?>
                    <li class="<?php echo e((isset($activemenu['main']) && $activemenu['main'] == 'settings') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('dashboard.settings.index')); ?>"><i class="fa fa-code"></i>
                            <span>Site Settings</span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </section>
</aside>
<?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>