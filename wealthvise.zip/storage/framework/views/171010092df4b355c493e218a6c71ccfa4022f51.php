<?php $__env->startSection('pageheader', $role->name); ?>


<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Member Management
            <small>Manage <?php echo e($role->name); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="">Member Management</li>
            <li class="active"><a href="<?php echo e(route('dashboard.members.index', ['type' => $role->slug])); ?>"><?php echo e($role->name); ?></a></li>
            <li class="active">Add New</li>
        </ol>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Add New <?php echo e($role->name); ?></h3>

                <div class="box-tools pull-right">
                    
                </div>
            </div>
            <form action="<?php echo e(route('dashboard.members.create', ['type' => $role->slug])); ?>" method="POST" id="memberform">
                <div class="box-body">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label>Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="name">
                        </div>

                        <div class="form-group col-md-4">
                            <label>Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="email">
                        </div>

                        <div class="form-group col-md-4">
                            <label>Mobile <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="mobile">
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-md btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('#memberform').validate({
            rules: {
                name: {
                    required: true,
                },
                email: {
                    required: true,
                    email: true,
                },
                mobile: {
                    required: true,
                    number: true,
                    maxlength: 10,
                    minlength: 10,
                },
            },
            errorElement: "p",
            errorPlacement: function ( error, element ) {
                if ( element.prop("tagName").toLowerCase() === "select" ) {
                    error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                } else {
                    error.insertAfter( element );
                }
            },
            submitHandler: function() {
                var form = $('#memberform');

                Pace.track(function(){
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            form.find('button[type="submit"]').button('loading');
                        },
                        success:function(data){
                            notify(data.status, 'success');
                            form.find('button[type="submit"]').button('reset');
                            form[0].reset();
                        },
                        error: function(errors) {
                            form.find('button[type="submit"]').button('reset');
                            showErrors(errors, form);
                        }
                    });
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/dashboard/members/addcustomer.blade.php ENDPATH**/ ?>