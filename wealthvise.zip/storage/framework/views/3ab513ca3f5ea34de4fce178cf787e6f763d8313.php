<?php $__env->startSection('pageheader', 'CMS'); ?>


<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Content Management
            <small>Manage CMS</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="">Content Management</li>
            <li class=""><a href="<?php echo e(route('dashboard.cms.index', ['type' => 'contents'])); ?>">CMS</a></li>
            <li class="active"><?php echo e($content->page_name); ?></li>
        </ol>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Update Content</h3>

                <div class="box-tools pull-right">
                    
                </div>
            </div>
            <form action="<?php echo e(route('dashboard.cms.submitcms')); ?>" method="POST" id="contentform">
                <div class="box-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="operation" value="contentedit">
                    <input type="hidden" name="id" value="<?php echo e($content->id); ?>">

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label>Page Name</label>
                            <input type="text" class="form-control" disabled value="<?php echo e($content->page_name); ?>">
                        </div>

                        <div class="form-group col-md-4">
                            <label>Identification Slug</label>
                            <input type="text" class="form-control" disabled value="<?php echo e($content->slug); ?>">
                        </div>

                        <div class="form-group col-md-4">
                            <label>Page Title <span class="text-danger">*</span></label>
                            <input type="text" name="page_title" class="form-control" value="<?php echo e($content->page_title); ?>">
                        </div>

                        <div class="form-group col-md-12">
                            <label>Page Content</label>
                            <textarea id="ck-editor" name="content"><?php echo $content->content; ?></textarea>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Meta Tags</label>
                            <textarea class="form-control" name="meta_tags" placeholder="SEO Tools"><?php echo $content->meta_tags; ?></textarea>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Meta Title</label>
                            <textarea class="form-control" name="meta_title" placeholder="SEO Tools"><?php echo $content->meta_title; ?></textarea>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Meta Description</label>
                            <textarea class="form-control" name="meta_description" placeholder="SEO Tools"><?php echo $content->meta_title; ?></textarea>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Meta Keywords</label>
                            <textarea class="form-control" name="meta_keywords" placeholder="SEO Tools"><?php echo $content->meta_keywords; ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-md btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('#contentform').validate({
            rules: {
                page_title: {
                    required: true,
                },
            },
            errorElement: "p",
            errorPlacement: function ( error, element ) {
                if ( element.prop("tagName").toLowerCase() === "select" ) {
                    error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                } else {
                    error.insertAfter( element );
                }
            },
            submitHandler: function() {
                for (instance in CKEDITOR.instances) {
                    CKEDITOR.instances[instance].updateElement();
                }

                var form = $('#contentform');

                Pace.track(function(){
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            form.find('button[type="submit"]').button('loading');
                        },
                        success:function(data){
                            notify(data.status, 'success');
                            form.find('button[type="submit"]').button('reset');
                        },
                        error: function(errors) {
                            form.find('button[type="submit"]').button('reset');
                            showErrors(errors, form);
                        }
                    });
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/dashboard/cms/contentedit.blade.php ENDPATH**/ ?>