<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Profile
            <small><?php echo e($user->name); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Profile</li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-3">
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <a href="javascript:;" data-toggle="modal" data-target="#imagemodal">
                            <img class="profile-user-img img-responsive img-circle" src="<?php echo e(Auth::user()->avatar); ?>">
                        </a>

                        <h3 class="profile-username text-center"><?php echo e(Auth::user()->name); ?></h3>

                        <p class="text-muted text-center">Software Engineer</p>

                        

                        <a href="<?php echo e(route('logout')); ?>" class="btn btn-primary btn-block"><b><i class="fa fa-power-off"></i></b> Logout</a>
                    </div>
                </div>
            </div>

            <div class="col-md-9">
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="bg-gray active"><a href="#basicdetails" data-toggle="tab"><i class="fa fa-gear"></i> Basic Details</a></li>
                        <li class="bg-gray "><a href="#password" data-toggle="tab"><i class="fa fa-lock"></i> Change Password</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="basicdetails">
                            <form id="profileform" method="POST" action="<?php echo e(route('dashboard.profile')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="type" value="basicdetails">

                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label>Name <span class="text-danger">*</span></label>
                                        <input name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control" placeholder="Enter full name">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label>Email <span class="text-danger">*</span></label>
                                        <input name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" placeholder="Enter email address">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label>Mobile</label>
                                        <input name="mobile" value="<?php echo e(Auth::user()->mobile); ?>" class="form-control" placeholder="Enter mobile number">
                                    </div>
                                </div>
                                <footer class="text-left">
                                    <button type="submit" class="btn btn-primary btn-md">Submit</button>
                                </footer>
                            </form>
                        </div>

                        <div class="tab-pane" id="password">
                            <form id="passwordform" method="POST" action="<?php echo e(route('dashboard.profile')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="type" value="changepassword">

                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label>Current Password <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-md">
                                            <input type="password" name="current_password" value="" class="form-control" placeholder="Enter your current password">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn btn-info btn-flat eye-password"><i class="fa fa-eye"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label>New Password <span class="text-danger">*</span></label>
                                        <div class="input-group input-group-md">
                                            <input type="password" name="new_password" value="" class="form-control" placeholder="Enter your new password">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn btn-info btn-flat eye-password"><i class="fa fa-eye"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label>New Password Confirmation<span class="text-danger">*</span></label>
                                        <div class="input-group input-group-md">
                                            <input type="password" name="new_password_confirmation" value="" class="form-control" placeholder="Re-enter your new password">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn btn-info btn-flat eye-password"><i class="fa fa-eye"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <footer class="text-left">
                                    <button type="submit" class="btn btn-primary btn-md">Submit</button>
                                </footer>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fad-in" id="imagemodal">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Profile Picture</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form action="<?php echo e(route('dashboard.profile')); ?>" method="POST" id="imageform" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="profileimage">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Picture <span class="text-danger">*</span></label>
                            <input name="profile_image" accept="image/*" class="form-control" type="file">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Submit</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $('#profileform').validate({
        rules: {
            name: {
                required: true,
            },
            email: {
                required: true,
                email: true
            },
            mobile: {
                number: true,
                maxlength: 10,
                minlength: 10,
            },
        },
        messages: {
            name: {
                required: "Please enter your name",
            },
            email: {
                required: "Please enter your email address",
                email: "The inserted email address is invalid"
            },
            mobile: {
                number: "Please enter a valid mobile number",
                maxlength: "Mobile number should be of 10 digits",
                minlength: "Mobile number should be of 10 digits"
            }
        },
        errorElement: "p",
        errorPlacement: function ( error, element ) {
            if ( element.prop("tagName").toLowerCase() === "select" ) {
                error.insertAfter( element.closest( ".form-group" ).find(".select2") );
            } else {
                error.insertAfter( element );
            }
        },
        submitHandler: function() {
            var form = $('#profileform');

            Pace.track(function(){
                form.ajaxSubmit({
                    dataType:'json',
                    beforeSubmit:function(){
                        form.find('button[type="submit"]').button('loading');
                    },
                    success:function(data){
                        form.find('button[type="submit"]').button('reset');
                        notify(data.status, 'success');
                    },
                    error: function(errors) {
                        form.find('button[type="submit"]').button('reset');
                        showErrors(errors, form);
                    }
                });
            });
        }
    });

    $('#passwordform').validate({
        rules: {
            current_password: {
                required: true,
            },
            new_password: {
                required: true,
            },
            new_password_confirmation: {
                required: true,
            },
        },
        errorElement: "p",
        errorPlacement: function ( error, element ) {
            if ( element.prop("tagName").toLowerCase() === "select" ) {
                error.insertAfter( element.closest( ".form-group" ).find(".select2") );
            } else {
                error.insertAfter( element );
            }
        },
        submitHandler: function() {
            var form = $('#passwordform');

            Pace.track(function(){
                form.ajaxSubmit({
                    dataType:'json',
                    beforeSubmit:function(){
                        form.find('button[type="submit"]').button('loading');
                    },
                    success:function(data){
                        form[0].reset();
                        form.find('button[type="submit"]').button('reset');
                        notify(data.status, 'success');
                    },
                    error: function(errors) {
                        form.find('button[type="submit"]').button('reset');
                        showErrors(errors, form);
                    }
                });
            });
        }
    });

    $('#imageform').validate({
        rules: {
            profile_image: {
                required: true,
            },
        },
        profile_image: {
            name: {
                required: "Please select an image",
            },
        },
        errorElement: "p",
        errorPlacement: function ( error, element ) {
            if ( element.prop("tagName").toLowerCase() === "select" ) {
                error.insertAfter( element.closest( ".form-group" ).find(".select2") );
            } else {
                error.insertAfter( element );
            }
        },
        submitHandler: function() {
            var form = $('#imageform');

            Pace.track(function(){
                form.ajaxSubmit({
                    dataType:'json',
                    beforeSubmit:function(){
                        form.find('button[type="submit"]').button('loading');
                    },
                    success:function(data){
                        form.find('button[type="submit"]').button('reset');
                        location.reload();
                    },
                    error: function(errors) {
                        form.find('button[type="submit"]').button('reset');
                        showErrors(errors, form);
                    }
                });
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/profile.blade.php ENDPATH**/ ?>