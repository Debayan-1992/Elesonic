<?php error_reporting(0) ?>
<?php $__env->startSection('pageheader', 'Blogs'); ?>


<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Blogs Management
            <small><?php echo e(isset($blog) ? 'Edit' : 'Add New'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class=""><a href="<?php echo e(route('dashboard.blogs.index')); ?>">Blogs Management</a></li>
            <li class="active"><small><?php echo e(isset($blog) ? 'Edit' : 'Add New'); ?></small></li>
        </ol>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo isset($blog) ? 'Edit Blog' : 'Add New Blog'; ?></h3>

                <div class="box-tools pull-right">
                    
                </div>
            </div>
            <form action="<?php echo e(route('dashboard.blogs.submit')); ?>" method="POST" id="contentform">
                <div class="box-body">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="operation" value="<?php echo e(isset($blog) ? 'edit' : 'new'); ?>">
                    <input type="hidden" name="id" value="<?php echo e(isset($blog) ? $blog->id : ''); ?>">

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Blog Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter blog tittle" name="title" value="<?php echo e(isset($blog) ? $blog->title : ''); ?>">
                        </div>

                        <div class="form-group col-md-6">
                            <label>Feature Image <?php echo !isset($blog) ? '<span class="text-danger">*</span>' : ''; ?></label>
                            <input type="file" class="form-control" name="blog_image">
                        </div>

                        <div class="form-group col-md-12">
                            <label>Blog Content <span class="text-danger">*</span></label>
                            <textarea id="ck-editor" name="content"><?php echo isset($blog) ? $blog->content : ''; ?></textarea>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Meta Tags</label>
                            <textarea class="form-control" name="meta_tags" placeholder="SEO Tools"><?php echo e(isset($blog) ? $blog->meta_tags : ''); ?></textarea>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Meta Title</label>
                            <textarea class="form-control" name="meta_title" placeholder="SEO Tools"><?php echo e(isset($blog) ? $blog->meta_title : ''); ?></textarea>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Meta Description</label>
                            <textarea class="form-control" name="meta_description" placeholder="SEO Tools"><?php echo e(isset($blog) ? $blog->meta_title : ''); ?></textarea>
                        </div>

                        <div class="form-group col-md-6">
                            <label>Meta Keywords</label>
                            <textarea class="form-control" name="meta_keywords" placeholder="SEO Tools"><?php echo e(isset($blog) ? $blog->meta_keywords : ''); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-md btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('#contentform').validate({
            rules: {
                title: {
                    required: true,
                },
                content: {
                    required: true,
                },
            },
            errorElement: "p",
            errorPlacement: function ( error, element ) {
                if ( element.prop("tagName").toLowerCase() === "select" ) {
                    error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                } else {
                    error.insertAfter( element );
                }
            },
            submitHandler: function() {
                for (instance in CKEDITOR.instances) {
                    CKEDITOR.instances[instance].updateElement();
                }

                var form = $('#contentform');

                Pace.track(function(){
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            form.find('button[type="submit"]').button('loading');
                        },
                        success:function(data){
                            notify(data.status, 'success');
                            form.find('button[type="submit"]').button('reset');

                            <?php if(!isset($blog)): ?>
                                location.reload();
                            <?php endif; ?>
                        },
                        error: function(errors) {
                            form.find('button[type="submit"]').button('reset');
                            showErrors(errors, form);
                        }
                    });
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/dashboard/blogs/submit.blade.php ENDPATH**/ ?>