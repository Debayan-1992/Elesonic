<?php $__env->startSection('pageheader', 'Default Permission'); ?>


<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>
            Roles & Permissions
            <small>Manage Permission for <?php echo e($role->name); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('dashboard.home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="">Tools</li>
            <li class=""><a href="<?php echo e(route('dashboard.tools.roles')); ?>">Roles</a></li>
            <li class="active">Default Permission</li>
        </ol>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Permission List</h3>

                <div class="box-tools pull-right"></div>
            </div>
            <form action="<?php echo e(route('dashboard.tools.rolepermissions.submit')); ?>" method="POST" id="permissionform">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="role_id" value="<?php echo e($role->id); ?>">
                <div class="box-body">
                    <table class="table table-bordered table-striped" style="width: 100%">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Permissions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $flag = false; ?>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($permissions[$key]) > 0): ?>
                                    <?php $flag = true; ?>
                                    <tr>
                                        <td style="width: 10%;"><?php echo e(ucfirst($key)); ?></td>
                                        <td>
                                            <div class="row">
                                                <?php $__currentLoopData = $permissions[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-3">
                                                        <input <?php echo e((in_array($item->id, $default)) ? 'checked' : ''); ?> type="checkbox" name="permissions[]" id="<?php echo e($item->slug); ?>" value="<?php echo e($item->id); ?>"> <label for="<?php echo e($item->slug); ?>">&nbsp;<?php echo e($item->name); ?></label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($flag == false): ?>
                                <tr><td colspan="2" class="text-center">No Data Found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="box-footer text-right">
                    <button type="submit" class="btn btn-md btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        td{
            padding: 10px !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('#permissionform').validate({
            rules: {
                name: {
                    required: true,
                },
                slug: {
                    required: true,
                },
                type: {
                    required: true,
                }
            },
            errorElement: "p",
            errorPlacement: function ( error, element ) {
                if ( element.prop("tagName").toLowerCase() === "select" ) {
                    error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                } else {
                    error.insertAfter( element );
                }
            },
            submitHandler: function() {
                var form = $('#permissionform');

                Pace.track(function(){
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            form.find('button[type="submit"]').button('loading');
                        },
                        success:function(data){
                            notify(data.status, 'success');
                            form.find('button[type="submit"]').button('reset');
                        },
                        error: function(errors) {
                            form.find('button[type="submit"]').button('reset');
                            showErrors(errors, form);
                        }
                    });
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/dashboard/tools/rolepermissions.blade.php ENDPATH**/ ?>