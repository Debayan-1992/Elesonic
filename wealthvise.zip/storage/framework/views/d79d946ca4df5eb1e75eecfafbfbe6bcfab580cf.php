<div class="box">
    <form id="searchform">
        <div class="box-body">
            <div class="row">
                <?php echo $__env->yieldPushContent('filterfields'); ?>
            </div>
        </div>
        <div class="box-footer text-right">
            <button type="button" class="btn btn-md btn-danger"><i class="fa fa-remove"></i>&nbsp;Reset</button>
            <button type="submit" class="btn btn-md btn-primary"><i class="fa fa-search"></i>&nbsp;Filter</button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\firstlaravel\resources\views/inc/filter.blade.php ENDPATH**/ ?>