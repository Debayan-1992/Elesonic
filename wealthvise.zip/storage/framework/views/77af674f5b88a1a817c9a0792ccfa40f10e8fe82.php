<?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            $.toast({
                heading: 'Error Message',
                text: "<?php echo e($error); ?>",
                showHideTransition: 'slide',
                position : 'top-right',
                icon: 'error'
            })
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <script>
        $.toast({
            heading: 'Success Message',
            text: "<?php echo e(session('success')); ?>",
            showHideTransition: 'slide',
            position : 'top-right',
            icon: 'success'
        })
    </script>
<?php endif; ?>

<?php if(session('warning')): ?>
    <script>
        $.toast({
            heading: 'Warning Message',
            text: "<?php echo e(session('warning')); ?>",
            showHideTransition: 'slide',
            position : 'top-right',
            icon: 'warning'
        })
    </script>
<?php endif; ?>

<?php if(session('status')): ?>
    <script>
        $.toast({
            heading: 'Success Message',
            text: "<?php echo e(session('status')); ?>",
            showHideTransition: 'slide',
            position : 'top-right',
            icon: 'success'
        })
    </script>
<?php endif; ?>


<?php if(session('resent')): ?>
    <script>
        $.toast({
            heading: 'Success Message',
            text: "A fresh verification link has been sent to your email address.",
            showHideTransition: 'slide',
            position : 'top-right',
            icon: 'success'
        })
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\wealthvise\resources\views/inc/messages.blade.php ENDPATH**/ ?>